export const LOGIN_GREETINGS = 'Hello from Login';

export const LOGIN_CLASS_NAMES = {
  LOGO: 'login__logo logo',
};
